x = 0
while x < 10:
    print('jestem programistą Pytona')
    x += 1