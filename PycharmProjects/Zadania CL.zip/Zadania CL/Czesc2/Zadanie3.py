print("Podaj pierwsze imię")
first_name = input()
print("Podaj drugie imię")
second_name = input()

if first_name == second_name:
    print("Takie same")
else:
    print("Różne")