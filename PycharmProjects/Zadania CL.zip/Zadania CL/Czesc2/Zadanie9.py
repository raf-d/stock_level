numbers = []
for i in range(1, 9):
    numbers.append(i)
#    print(f"liczba: {i}")  #  wypisanie liczb w trakcie tworzenia listy

for i in range(len(numbers)):
    print(f"liczna: {i + 1}")  # wypisanie liczb po utworzeniu listy
