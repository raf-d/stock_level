cat = "kot1"
dog = "koza"
print(cat < dog)

#  Python porównuje znak po znaku w obu wyrazach.
#  Jeżeli znaki nie są identyczne, są porównywane zgodnie z kolejnością Unicode
#  Wielkie litery są przed małymi
