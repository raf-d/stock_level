x = 2
for i in range(11):
    print(x**i)