father = 1974
child = 2007
roznica = child - father
print(f"Ojciec jest starszy od dziecka o {roznica} lat.")