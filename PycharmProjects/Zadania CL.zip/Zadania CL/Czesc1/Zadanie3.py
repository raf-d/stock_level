num1 = 125
num2 = 12

modulo_result = num1 % num2

print(modulo_result)