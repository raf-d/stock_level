counter = 145
print(counter)
counter += 1
print(counter)
counter -= 1
print(counter)