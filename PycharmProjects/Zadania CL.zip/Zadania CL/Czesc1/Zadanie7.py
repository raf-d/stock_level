result = 11 / 7
print("11 : 7 = " + str(round(result, 2)))