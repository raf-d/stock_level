letters = ['a', 'b', 'c', 'd', 'e']

x = ' '.join(letters)
print(x)