print("Podaj swoje imię: ")
name = input()
print("Podaj rok swojego urodzenia: ")
year = int(input())
age = 2020 - year
print(f'Użytkownik: {name} jest w wieku {age} lat.')