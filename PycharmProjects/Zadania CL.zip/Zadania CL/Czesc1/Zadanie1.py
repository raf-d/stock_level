name = ''
surname = ''

print('Podaj imię:')
name = input()

print('podaj nazwisko:')
surname = input()

print(f'{name} {surname} jest programistą Pythona!')