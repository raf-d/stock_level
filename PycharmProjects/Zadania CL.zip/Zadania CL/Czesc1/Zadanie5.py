num1 = 123
num2 = 12

result = num1 > num2

print(result)